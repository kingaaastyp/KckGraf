﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AplikacjaTekstowa;
using AplikacjaTekstowa.Models;

namespace Kck_graf.Views
{
    public partial class EditBookView : UserControl
    {
        private readonly BookRepository _repository;

        public EditBookView(BookRepository repository)
        {
            InitializeComponent();
            _repository = repository;
            LoadBooks();
        }

        private void LoadBooks()
        {
            // Załaduj książki do ComboBoxa
            BookSelector.ItemsSource = _repository.GetBooks();
           // BookSelector.DisplayMemberPath = "Title";
            //BookSelector.SelectedValuePath = "Id";
        }

        private void BookSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Pobierz wybraną książkę i uzupełnij pola
            if (BookSelector.SelectedItem is Book selectedBook)
            {
                TitleInput.Text = selectedBook.Title;
                AuthorInput.Text = selectedBook.Author;
                GenreInput.Text = selectedBook.Genre;
                PageCountInput.Text = selectedBook.PageCount.ToString();
                YearInput.Text = selectedBook.Year.ToString();
                DescriptionInput.Text = selectedBook.Description;
            }
        }

        private void BookSelector_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filter = ((ComboBox)sender).Text.ToLower();
            BookSelector.ItemsSource = _repository.GetBooks()
                .Where(book => book.Title.ToLower().Contains(filter) || book.Author.ToLower().Contains(filter))
                .ToList();
        }
        private void BookSelector_PreviewKeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (sender is ComboBox comboBox && !string.IsNullOrEmpty(comboBox.Text))
            {
                string searchText = comboBox.Text.ToLower();

                // Filtruj książki po tytule, autorze lub roku
                var filteredBooks = _repository.GetBooks()
                    .Where(book => book.Title.ToLower().Contains(searchText) ||
                                   book.Author.ToLower().Contains(searchText) ||
                                   book.Year.ToString().Contains(searchText))
                    .ToList();

                comboBox.ItemsSource = filteredBooks;

                // Ponowne otwarcie rozwijanej listy
                comboBox.IsDropDownOpen = true;
            }
        }
    

        private void BookSelector_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!BookSelector.IsDropDownOpen)
            {
                BookSelector.IsDropDownOpen = true; // Automatycznie otwiera listę po kliknięciu
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (BookSelector.SelectedItem is not Book originalBook)
                {
                    MessageBox.Show("Wybierz książkę do edycji.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Utwórz obiekt z zaktualizowanymi danymi
                var updatedBook = new Book
                {
                    Title = TitleInput.Text.Trim(),
                    Author = AuthorInput.Text.Trim(),
                    Genre = GenreInput.Text.Trim(),
                    PageCount = int.Parse(PageCountInput.Text.Trim()),
                    Year = int.Parse(YearInput.Text.Trim()),
                    Description = DescriptionInput.Text.Trim()
                };

                // Wywołaj UpdateBook z oryginalną i zaktualizowaną książką
                _repository.UpdateBook(originalBook, updatedBook);

                MessageBox.Show("Zmiany zostały zapisane!", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);

                // Powrót do widoku listy książek
                var mainWindow = Window.GetWindow(this) as MainWindow;
                mainWindow?.ShowBooksView(null, null);
            }
            catch (FormatException)
            {
                MessageBox.Show("Proszę wprowadzić poprawne dane w polach liczbowych (Liczba stron, Rok wydania).", 
                    "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Powrót do widoku listy książek
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.ShowBooksView(null, null);
        }
    }
}
