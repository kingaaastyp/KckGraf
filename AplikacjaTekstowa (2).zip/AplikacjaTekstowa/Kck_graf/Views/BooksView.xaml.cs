﻿using System.Linq;
using System.Windows.Controls;
using AplikacjaTekstowa;
using AplikacjaTekstowa.Models;

namespace Kck_graf.Views
{
    public partial class BooksView : UserControl
    {
        private readonly MainWindow _mainWindow;
        private readonly BookRepository _repository;

        public BooksView(MainWindow mainWindow, BookRepository repository)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            _repository = repository;
            LoadBooks();
        }

        private void LoadBooks()
        {
            BooksList.ItemsSource = _repository.GetBooks();
        }

        private void SortBooks_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var books = _repository.GetBooks();

            // Pobierz wybrane opcje sortowania
            string selectedSortOption = (SortByCombo.SelectedItem as ComboBoxItem)?.Content.ToString();

            // Wyszukiwanie
            string authorQuery = SearchAuthorBox.Text.Trim().ToLower();
            string titleQuery = SearchTitleBox.Text.Trim().ToLower();

            // Filtruj po autorze i tytule
            books = books.Where(b =>
                (string.IsNullOrEmpty(authorQuery) || b.Author.ToLower().Contains(authorQuery)) &&
                (string.IsNullOrEmpty(titleQuery) || b.Title.ToLower().Contains(titleQuery))
            ).ToList();

            // Sortowanie
            if (selectedSortOption == "Tytuł (Rosnąco)")
                books = books.OrderBy(b => b.Title).ToList();
            else if (selectedSortOption == "Tytuł (Malejąco)")
                books = books.OrderByDescending(b => b.Title).ToList();
            else if (selectedSortOption == "Autor (Rosnąco)")
                books = books.OrderBy(b => b.Author).ToList();
            else if (selectedSortOption == "Autor (Malejąco)")
                books = books.OrderByDescending(b => b.Author).ToList();

            // Zaktualizuj widok
            BooksList.ItemsSource = books;
        }

        private void BooksList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedBook = (Book)BooksList.SelectedItem;
            if (selectedBook != null)
            {
                _mainWindow.MainContent.Content = new BookDetailsView(_mainWindow, selectedBook, _repository);
            }
        }
    }
}
