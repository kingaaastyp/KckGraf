﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AplikacjaTekstowa;
using AplikacjaTekstowa.Models;

namespace Kck_graf.Views
{
    public partial class DeleteBookView : UserControl
    {
        private readonly BookRepository _repository;

        public DeleteBookView(BookRepository repository)
        {
            InitializeComponent();
            _repository = repository;
            LoadBooks();
        }

        private void LoadBooks()
        {
            // Załaduj książki do ComboBoxa
            BookSelector.ItemsSource = _repository.GetBooks();
        }

        private void BookSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BookSelector.SelectedItem is Book selectedBook)
            {
                // Wyświetl szczegóły książki
                BookDetails.Text = $"Tytuł: {selectedBook.Title}\n" +
                                   $"Autor: {selectedBook.Author}\n" +
                                   $"Gatunek: {selectedBook.Genre}\n" +
                                   $"Liczba stron: {selectedBook.PageCount}\n" +
                                   $"Rok wydania: {selectedBook.Year}\n" +
                                   $"Opis: {selectedBook.Description}";
            }
            else
            {
                BookDetails.Text = "Wybierz książkę, aby zobaczyć szczegóły.";
            }
        }

        private void DeleteBook_Click(object sender, RoutedEventArgs e)
        {
            if (BookSelector.SelectedItem is Book selectedBook)
            {
                var confirmResult = MessageBox.Show(
                    $"Czy na pewno chcesz usunąć książkę \"{selectedBook.Title}\" autorstwa {selectedBook.Author} z roku {selectedBook.Year}?",
                    "Potwierdzenie usunięcia",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirmResult == MessageBoxResult.Yes)
                {
                    _repository.RemoveBook(selectedBook);
                    MessageBox.Show("Książka została usunięta.", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadBooks(); // Odśwież listę książek
                    BookDetails.Text = "Wybierz książkę, aby zobaczyć szczegóły."; // Reset szczegółów
                }
            }
            else
            {
                MessageBox.Show("Proszę wybrać książkę do usunięcia.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.ShowBooksView(null, null); // Powrót do widoku głównego
        }

        private void BookSelector_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (sender is ComboBox comboBox && !string.IsNullOrEmpty(comboBox.Text))
            {
                string searchText = comboBox.Text.ToLower();

                // Filtruj książki po tytule, autorze lub roku
                var filteredBooks = _repository.GetBooks()
                    .Where(book => book.Title.ToLower().Contains(searchText) ||
                                   book.Author.ToLower().Contains(searchText) ||
                                   book.Year.ToString().Contains(searchText))
                    .ToList();

                comboBox.ItemsSource = filteredBooks;
                comboBox.IsDropDownOpen = true;
            }
        }

        private void BookSelector_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!BookSelector.IsDropDownOpen)
            {
                BookSelector.IsDropDownOpen = true; // Automatyczne otwarcie listy
            }
        }
    }
}
