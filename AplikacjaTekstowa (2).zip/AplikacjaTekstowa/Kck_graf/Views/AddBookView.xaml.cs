﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AplikacjaTekstowa;
using AplikacjaTekstowa.Models;

namespace Kck_graf
{
    public partial class AddBookView : UserControl
    {
        private readonly BookRepository _repository;

        public AddBookView(BookRepository repository)
        {
            InitializeComponent();
            _repository = repository;
        }

        private void AddBook_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Funkcja do poprawiania pierwszej litery na wielką
                string FormatText(string input)
                {
                    if (string.IsNullOrWhiteSpace(input)) return string.Empty;
                    return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(input.ToLower().Trim());
                }

                var newBook = new Book
                {
                    Title = FormatText(TitleInput.Text),
                    Author = FormatText(AuthorInput.Text),
                    Genre = FormatText(GenreInput.Text),
                    PageCount = int.Parse(PageCountInput.Text.Trim()),
                    Year = int.Parse(YearInput.Text.Trim()),
                    Description = DescriptionInput.Text.Trim()
                };

                // Sprawdzenie, czy książka o takim samym tytule, autorze i roku już istnieje
                var existingBook = _repository.GetBooks().FirstOrDefault(b => 
                    b.Title.Equals(newBook.Title, StringComparison.OrdinalIgnoreCase) &&
                    b.Author.Equals(newBook.Author, StringComparison.OrdinalIgnoreCase) &&
                    b.Year == newBook.Year);

                if (existingBook != null)
                {
                    MessageBox.Show("Książka o takim tytule, autorze i roku wydania już istnieje.", 
                        "Duplikat książki", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                _repository.AddBook(newBook);

                MessageBox.Show("Książka została dodana!", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);

                // Powrót do widoku książek
                var mainWindow = Window.GetWindow(this) as MainWindow;
                mainWindow?.ShowBooksView(null, null);
            }
            catch (FormatException)
            {
                MessageBox.Show("Proszę wprowadzić poprawne dane w polach liczbowych (Liczba stron, Rok wydania).", 
                    "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Powrót do widoku książek
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.ShowBooksView(null, null);
        }
    }
}
