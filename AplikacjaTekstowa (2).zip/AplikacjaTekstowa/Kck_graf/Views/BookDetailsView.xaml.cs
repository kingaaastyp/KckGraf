﻿using System.Windows.Controls;
using System.Windows;
using AplikacjaTekstowa;
using AplikacjaTekstowa.Models;

namespace Kck_graf.Views
{
    public partial class BookDetailsView : UserControl
    {
        private readonly MainWindow _mainWindow;
        private readonly BookRepository _repository;

        public BookDetailsView(MainWindow mainWindow, Book selectedBook, BookRepository repository)
        {
            InitializeComponent(); // Inicjalizacja komponentów UI
            _mainWindow = mainWindow;
            _repository = repository;

            if (selectedBook == null)
            {
                MessageBox.Show("Nie wybrano żadnej książki do wyświetlenia szczegółów.");
                NavigateBack();
            }
            else
            {
                DataContext = selectedBook; // Powiązanie danych z widokiem
            }
        }

        private void NavigateBack()
        {
            _mainWindow.MainContent.Content = new BooksView(_mainWindow, _repository);
        }

        private void BackToBooks_Click(object sender, RoutedEventArgs e)
        {
            NavigateBack();
        }
    }
}