﻿using System.Windows;
using System.Windows.Controls;

namespace Kck_graf.Views
{
    public partial class WelcomeView : UserControl
    {
        private readonly MainWindow _mainWindow;

        public WelcomeView(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
        }

        private void EnterApp_Click(object sender, RoutedEventArgs e)
        {
            // Access MainContent directly and set the BooksView as the new content
            _mainWindow.MainContent.Content = new BooksView(_mainWindow, _mainWindow.Repository);
        }
    }
}