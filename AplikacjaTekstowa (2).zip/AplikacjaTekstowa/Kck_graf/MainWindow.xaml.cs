﻿using System.Windows;
using AplikacjaTekstowa;
using Kck_graf.Views;

namespace Kck_graf
{
    public partial class MainWindow : Window
    {
        public BookRepository Repository { get; }

        public MainWindow()
        {
            InitializeComponent();
            Repository = new BookRepository("books.json");
            ShowWelcomeScreen(); // Na początek ekran powitalny
        }

        public void ShowWelcomeScreen(object sender = null, RoutedEventArgs e = null)
        {
            MainContent.Content = new WelcomeView(this);
        }

        public void ShowBooksView(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new BooksView(this, Repository);
        }

        public void ShowAddBookView(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new AddBookView(Repository);
        }

        public void ShowEditBookView(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new EditBookView(Repository);
        }

        public void ShowDeleteBookView(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new DeleteBookView(Repository);
        }

        public void ExitApplication(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}