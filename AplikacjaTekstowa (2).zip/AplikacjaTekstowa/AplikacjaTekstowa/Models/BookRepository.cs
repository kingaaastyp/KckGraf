﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using AplikacjaTekstowa.Models;
using Spectre.Console;
using AplikacjaTekstowa.Views;
namespace AplikacjaTekstowa
{
    public class BookRepository
    {
        private List<Book> books;
        private readonly string filePath;

        public BookRepository(string filePath)
        {
            this.filePath = filePath;
            books = LoadBooksFromFile();
        }

        private List<Book> LoadBooksFromFile()  // Ładowanie książek z pliku JSON
        {
            try
            {
                if (!File.Exists(filePath)) return new List<Book>(); //pusta lista gdy nie istnieje
                string json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<List<Book>>(json) ?? new List<Book>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas ładowania pliku: {ex.Message}");
                return new List<Book>();
            }
        }

        public void SaveBooksToFile()
        {
            try
            {
                string json = JsonSerializer.Serialize(books, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, json);

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas zapisu pliku: {ex.Message}");
            }

        }

        public List<Book> GetBooks() => books;  // [obranie listy książek


        public void AddBook(Book book)
        {
            // sprawdzenie, czy książka już istnieje
            var existingBook = books.FirstOrDefault(b =>
                b.Title.Equals(book.Title, StringComparison.OrdinalIgnoreCase) &&
                b.Author.Equals(book.Author, StringComparison.OrdinalIgnoreCase) &&
                b.Year == book.Year);

            if (existingBook != null)
            {
                Console.WriteLine($"Książka \"{existingBook.Title}\" autorstwa {existingBook.Author} z roku {existingBook.Year} już istnieje.");
                if (AnsiConsole.Confirm("Czy chcesz wyświetlić szczegóły tej książki?"))
                {
                    Console.Clear();
                    new BookView().DisplayBookDetails(existingBook);
                }
                return;
            }
            books.Add(book);
            SaveBooksToFile();
        }

        public void UpdateBook(Book oldBook, Book updatedBook)
        {
            var index = books.IndexOf(oldBook);
            if (index != -1)
            {
                books[index] = updatedBook; //za starą nowa
                SaveBooksToFile();
            }
        }

        public void RemoveBook(Book book)
        {
            books.Remove(book);
            SaveBooksToFile();
        }

        public bool DoesBookExist(string title, string author)
        {
            return books.Any(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase) &&
                                  b.Author.Equals(author, StringComparison.OrdinalIgnoreCase));
        }

        public List<Book> SearchByTitle(string title) =>
            books.Where(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase)).ToList();

        public List<Book> SearchByAuthor(string author) 
        {
            return books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    

        
        // Sortowanie książek według tytułu
        public List<Book> SortByTitle(bool ascending = true)
        {
            return ascending
                ? books.OrderBy(b => b.Title).ToList()
                : books.OrderByDescending(b => b.Title).ToList();
        }

// Sortowanie książek według autora
        public List<Book> SortByAuthor(bool ascending = true)
        {
            return ascending
                ? books.OrderBy(b => b.Author).ToList()
                : books.OrderByDescending(b => b.Author).ToList();
        }

// Sortowanie listy książek według tytułu (dla wyszukiwania)
        public List<Book> SortBooksByTitle(List<Book> booksToSort, bool ascending = true)
        {
            return ascending
                ? booksToSort.OrderBy(b => b.Title).ToList()
                : booksToSort.OrderByDescending(b => b.Title).ToList();
        }
        
    }
}