﻿using AplikacjaTekstowa.Models;
using AplikacjaTekstowa.Views;
using Spectre.Console;

namespace AplikacjaTekstowa.Controllers
{
    public class BookController
    {
        private readonly BookRepository repository;
        private readonly BookView view;

        public BookController(BookRepository repository, BookView view)
        {
            this.repository = repository;
            this.view = view;
        }

        public void Start()
        {
            bool running = true; // Flaga wskazująca, czy aplikacja działa

            while (running)
            {
                view.DisplayHeader();
                int choice = view.DisplayMenu();
                
                switch (choice)
{
     case 1:
         // Wyświetlanie wszystkich książek z możliwością sortowania
        var sortCriteria = AnsiConsole.Prompt(
            new SelectionPrompt<string>()
                .Title("[yellow]Wybierz kryterium sortowania:[/]")
                .AddChoices("Tytuł", "Autor", "Brak"));
        

        List<Book> books;

        if (sortCriteria == "Brak")
        {
            books = repository.GetBooks();
        }
        else
        {
            // Kierunek sortowania (rosnąco/malejąco)
            string sortOrder = view.AskForSortOrder($"kryterium {sortCriteria.ToLower()}");
            bool ascending = sortOrder == "Rosnąco";

            books = sortCriteria == "Tytuł"
                ? repository.SortByTitle(ascending)
                : repository.SortByAuthor(ascending);
        }

        view.DisplayBooksWithDetailsOption(books); //wyświetlanie +możliwość z szczegolowym
        view.ShowReturningAnimation("Powrót do menu");
        view.ConsoleClear();
        break;



    case 2: //szukanie ksiązki po tytule
        string title = view.GetInput("Podaj tytuł: ");
        List<Book> booksByTitle = repository.SearchByTitle(title);
        view.DisplayBooksWithDetailsOption(booksByTitle);
        view.ShowReturningAnimation("Powrót do menu");
        break;

    case 3: // szukanie książki po autorze + sortowanie 
        string author = view.GetInput("Podaj autora: ");
        List<Book> booksByAuthor = repository.SearchByAuthor(author);
        if (booksByAuthor.Count == 0)
        { 
            view.ConsoleWriteString("Nie znaleziono autora o podanej nazwie.");
        }
        else
        {
            string sortOptionAutor = view.AskForSortOrder("tytułu (rosnąco/malejąco/brak)");

            if (sortOptionAutor == "Rosnąco")
            {
                booksByAuthor = repository.SortBooksByTitle(booksByAuthor, true); // Sortowanie rosnące
            }
            else if (sortOptionAutor == "Malejąco")
            {
                booksByAuthor = repository.SortBooksByTitle(booksByAuthor, false); // Sortowanie malejące
            }
            view.DisplayBooksWithDetailsOption(booksByAuthor);

        }
        view.ShowReturningAnimation("Powrót do menu");
        break;

    case 4: //nowa książka
        var newBook = view.PromptForBookDetailsInteractive(repository);
        if (newBook == null)
        {
            view.DisplayMessage("Proces dodawania książki został anulowany.", Color.Red);
            break;
        }
        repository.AddBook(newBook);
        view.DisplayMessage("Dodano książkę.", Color.Green);
        view.ShowReturningAnimation("Powrót do menu");
        break;

    case 5: //usuń książkę
        string titleToRemove = view.GetInput("Podaj tytuł książki do usunięcia: ");
        string authorToRemove = view.GetInput("Podaj autora książki do usunięcia: ");
        var bookToRemove = repository.GetBooks()
            .Find(b => b.Title.Equals(titleToRemove, StringComparison.OrdinalIgnoreCase)
                    && b.Author.Equals(authorToRemove, StringComparison.OrdinalIgnoreCase));
        if (bookToRemove != null)
        {
            if (view.ConfirmAction($"Czy na pewno chcesz usunąć książkę \"{bookToRemove.Title}\" autorstwa {bookToRemove.Author}?"))
            {
                repository.RemoveBook(bookToRemove);
                view.ConsoleWriteString("Usunięto książkę.");
            }
            else
            {
                view.ConsoleWriteString("Anulowano usuwanie książki.");
            }
        }
        else
        {
            view.ConsoleWriteString("Nie znaleziono książki o podanym tytule i autorze.");
        }
        view.ShowReturningAnimation("Powrót do menu");
        break;

    case 6:
        string titleToEdit = view.GetInput("Podaj tytuł książki do edycji: ");
        string authorToEdit = view.GetInput("Podaj autora książki do edycji: ");
        var bookToEdit = repository.GetBooks()
            .Find(b => b.Title.Equals(titleToEdit, StringComparison.OrdinalIgnoreCase) &&
                       b.Author.Equals(authorToEdit, StringComparison.OrdinalIgnoreCase));

        if (bookToEdit != null)
        {
            view.DisplayBookDetailsWithoutPause(bookToEdit);
            if (view.ConfirmAction($"Czy chcesz edytować książkę \"{bookToEdit.Title}\" autorstwa {bookToEdit.Author}?"))
            {
                var updatedBook = view.EditBookDetailsInteractive(bookToEdit);
                repository.UpdateBook(bookToEdit, updatedBook);
                view.ConsoleWriteString($"Książka \"{updatedBook.Title}\" została zaktualizowana.");
            }
            else
            {
                view.ConsoleWriteString("Edycja książki została anulowana.");
            }
        }
        else
        {
            view.ConsoleWriteString("Nie znaleziono książki o podanym tytule.");
        }
        view.ShowReturningAnimation("Powrót do menu");
        break;

    case 7:
        view.ConsoleWriteString("Wyjście z aplikacji.");
        running = false;
        break;

    default:
        view.ConsoleWriteString("Nieprawidłowa opcja.");
        break;
}

            }
        }
    }
}
