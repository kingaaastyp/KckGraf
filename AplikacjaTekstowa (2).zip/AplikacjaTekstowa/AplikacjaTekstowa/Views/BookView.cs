﻿using AplikacjaTekstowa.Models;
using Spectre.Console;

namespace AplikacjaTekstowa.Views
{
    public class BookView
    {
        public void DisplayHeader() //panel 
        {
            Console.Clear();

            // Tworzenie panelu
            var titlePanel = new Panel(new FigletText("ALBUM KSIĄŻEK").Centered().Color(Color.Orange3))
            {
                Border = BoxBorder.Heavy,
                BorderStyle = new Style(foreground: Color.White),
                Padding = new Padding(2, 2),
            };

            AnsiConsole.Write(titlePanel);
        }

        
        //podkreślenia na zielono
        public void DisplayMessage(string message, Color? color = null)
        {
            color ??= Color.Orange3;

            AnsiConsole.MarkupLine($"[{color}]{message}[/]");
        }

        public string GetInput(string prompt) //od uzytkownika 
        {
            return AnsiConsole.Ask<string>($"[yellow]{prompt}[/]");
        }
        
        public int DisplayMenu()
        {
            DisplayHeader();   // Wyświetlenie nagłówka
            
            var choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title("[yellow]Wybierz opcję z menu:[/]")
                    .AddChoices(
                        "1. Wyświetl wszystkie książki",
                        "2. Wyszukaj książkę po tytule",
                        "3. Wyszukaj książkę po autorze",
                        "4. Dodaj nową książkę",
                        "5. Usuń książkę",
                        "6. Edytuj książkę",
                        "7. Wyjdź")
                    .HighlightStyle(new Style(foreground: Color.Orange3))
            );

            if (int.TryParse(choice.Substring(0, 1), out int selectedOption))   // pobieranie  nr wyboru z pierwszego znaku
            {
                return selectedOption;
            }

            return DisplayMenu(); // Powrót do menu w przypadku błędu
        }


        public string CapitalizeWords(string input) //kapitaliacja
        {
            if (string.IsNullOrWhiteSpace(input)) return input;
            return string.Join(" ", input.Split(' ')
                .Select(word => char.ToUpper(word[0]) + word.Substring(1).ToLower()));
        }


        public void DisplayBookDetails(Book book)
        {
            // wyswwietla szczegoly książki w formie panelu
            var detailsPanel = new Panel(
                $"[bold cyan]Tytuł:[/] {Markup.Escape(book.Title)}\n" +
                $"[bold cyan]Autor:[/] {Markup.Escape(book.Author)}\n" +
                $"[bold cyan]Gatunek:[/] {Markup.Escape(book.Genre)}\n" +
                $"[bold cyan]Liczba stron:[/] {book.PageCount}\n" +
                $"[bold cyan]Rok wydania:[/] {book.Year}\n" +
                $"[bold cyan]Opis:[/] {Markup.Escape(book.Description)}")
            {
                Border = BoxBorder.Heavy,
                BorderStyle = new Style(foreground: Color.Green),
                Header = new PanelHeader(" Szczegóły książki ", Justify.Center)
            };

            AnsiConsole.Write(detailsPanel);

            // Informacja o powrocie
            AnsiConsole.MarkupLine("\n[grey]Naciśnij dowolny klawisz, aby wrócić do listy książek...[/]");
            Console.ReadKey();
        }


     

        public bool ConfirmAction(string question)
        {
            var choice = AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title($"[yellow]{question}[/]")
                    .AddChoices("Tak", "Nie")
            );
            return choice == "Tak";        
        }
        
        public void DisplayBookDetailsWithoutPause(Book book)
        {
            var detailsPanel = new Panel(
                $"[bold cyan]Tytuł:[/] {Markup.Escape(book.Title)}\n" +
                $"[bold cyan]Autor:[/] {Markup.Escape(book.Author)}\n" +
                $"[bold cyan]Gatunek:[/] {Markup.Escape(book.Genre)}\n" +
                $"[bold cyan]Liczba stron:[/] {book.PageCount}\n" +
                $"[bold cyan]Rok wydania:[/] {book.Year}\n" +
                $"[bold cyan]Opis:[/] {Markup.Escape(book.Description)}")
            {
                Border = BoxBorder.Heavy,
                BorderStyle = new Style(foreground: Color.Green),
                Header = new PanelHeader(" Szczegóły książki ", Justify.Center)
            };

            AnsiConsole.Write(detailsPanel);
        }

        public Book EditBookDetailsInteractive(Book book)
        {
            // Edycja książki
            string title = AnsiConsole.Ask<string>($"[yellow]Tytuł ([gray]{Markup.Escape(book.Title)}[/]):[/]", book.Title);
            string author = AnsiConsole.Ask<string>($"[yellow]Autor ([gray]{Markup.Escape(book.Author)}[/]):[/]", book.Author);
            string genre = AnsiConsole.Ask<string>($"[yellow]Gatunek ([gray]{Markup.Escape(book.Genre)}[/]):[/]", book.Genre);
            int pageCount = AnsiConsole.Ask<int>($"[yellow]Liczba stron ([gray]{book.PageCount}[/]):[/]", book.PageCount);
            int year = AnsiConsole.Ask<int>($"[yellow]Rok wydania ([gray]{book.Year}[/]):[/]", book.Year);
            string description = AnsiConsole.Ask<string>($"[yellow]Opis ([gray]{Markup.Escape(book.Description)}[/]):[/]", book.Description);

            return new Book
            {
                Title = title,
                Author = author,
                Genre = genre,
                PageCount = pageCount,
                Year = year,
                Description = description
            };
        }
        public void DisplayBooksWithDetailsOption(List<Book> books)
        {
            if (books.Count == 0)
            {
                DisplayMessage("Brak książek do wyświetlenia.", Color.Red);
                return;
            }

            while (true)
            {
                // Wyświetlenie menu z książkami
                var options = new List<string>();
                foreach (var book in books)
                {
                    options.Add($"{book.Title} - {book.Author}");
                }
                options.Add("[red]Wróć[/]"); //  opcja powrotu

                var choice = AnsiConsole.Prompt(
                    new SelectionPrompt<string>()
                        .Title("[cyan]Wybierz książkę, aby zobaczyć szczegóły, lub wróć:[/]")
                        .AddChoices(options)
                        .HighlightStyle(new Style(foreground: Color.Green4))
                );

                if (choice == "[red]Wróć[/]")
                {
                    // Powrót do poprzedniego menu
                    break;
                }

                // szukanie wybranej książkę
                var selectedBook = books.Find(book => $"{book.Title} - {book.Author}" == choice);

                if (selectedBook != null)
                {
                    AnsiConsole.Clear();
                    // Wyświetlenie szczegółów wybranej książki
                    DisplayBookDetails(selectedBook);
                }
            }
        }
public Book PromptForBookDetailsInteractive(BookRepository repository)
{
    // Pobranie tytułu książki
    string title = AnsiConsole.Ask<string>("[yellow]Podaj tytuł książki ([red]lub wpisz 'Anuluj', aby przerwać[/]):[/]");
    if (title.ToLower() == "anuluj")
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }
    title = CapitalizeWords(title); // Kapitalizacja tytułu

    // Pobranie autora książki
    string author = AnsiConsole.Ask<string>("[yellow]Podaj autora książki ([red]lub wpisz 'Anuluj', aby przerwać[/]):[/]");
    if (author.ToLower() == "anuluj")
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }
    author = CapitalizeWords(author); // Kapitalizacja autora

    // Sprawdzenie, czy książka już istnieje w bazie
    if (repository.DoesBookExist(title, author))
    {
        AnsiConsole.MarkupLine($"[red]Książka \"{title}\" autorstwa \"{author}\" już istnieje w bazie.[/]");
        if (AnsiConsole.Confirm("[yellow]Czy chcesz wyświetlić szczegóły tej książki?[/]"))
        {
            var existingBook = repository.GetBooks()
                .First(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase) &&
                            b.Author.Equals(author, StringComparison.OrdinalIgnoreCase));
            DisplayBookDetails(existingBook);
        }
        return null; // Przerwanie dodawania książki
    }

    // Pobranie gatunku książki
    string genre;
    do
    {
        genre = AnsiConsole.Ask<string>("[yellow]Podaj gatunek książki ([red]lub wpisz 'Anuluj', aby przerwać[/]):[/]");
        if (genre.ToLower() == "anuluj")
        {
            AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
            return null;
        }
        if (genre.Any(char.IsDigit))
        {
            AnsiConsole.MarkupLine("[red]Gatunek nie może zawierać cyfr![/]");
        }
    } while (genre.Any(char.IsDigit));
    genre = CapitalizeWords(genre); // Kapitalizacja gatunku

    // Pobranie liczby stron
    int pageCount = AnsiConsole.Ask<int>("[yellow]Podaj liczbę stron ([red]lub wpisz '0', aby anulować[/]):[/]");
    if (pageCount == 0)
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }

    // Pobranie roku wydania
    int year = AnsiConsole.Ask<int>("[yellow]Podaj rok wydania ([red]wpisz '0', aby anulować[/]):[/]");
    if (year == 0)
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }

    // Pobranie opisu książki
    string description = AnsiConsole.Ask<string>("[yellow]Podaj opis książki ([red]lub wpisz 'Anuluj'[/]):[/]");
    if (description.ToLower() == "anuluj")
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }

    //  potwierdzenie
    if (!AnsiConsole.Confirm("[red]Czy na pewno chcesz dodać tę książkę?[/]"))
    {
        AnsiConsole.MarkupLine("[red]Anulowano dodawanie książki.[/]");
        return null;
    }

    //  nowy obiekt książki
    return new Book
    {
        Title = title,
        Author = author,
        Genre = genre,
        PageCount = pageCount,
        Year = year,
        Description = description
    };
}



        public void ShowReturningAnimation(string message)
        {
            AnsiConsole.Status()
                .Start(message, ctx =>
                {
                    for (int i = 0; i < 3; i++)
                    {
                        ctx.Status(message + new string('.', i + 1));
                        Thread.Sleep(300);
                    }
                });
        }
        public string AskForSortOrder(string criteria)
        {
            return AnsiConsole.Prompt(
                new SelectionPrompt<string>()
                    .Title($"[yellow]Wybierz kierunek sortowania według {criteria}:[/]")
                    .AddChoices("Rosnąco", "Malejąco", "Brak")
            );
        }

        public void ConsoleWriteString(string message)
        {
            AnsiConsole.WriteLine(message);
        }

        public void ConsoleClear()
        {
            AnsiConsole.Clear();
        }
        
    }
}

